"use strict";

exports.PORT = 3002;
exports.PATH = "mongodb://localhost:27017/images";
