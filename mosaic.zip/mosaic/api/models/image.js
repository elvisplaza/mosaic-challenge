const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const imageSchema = new Schema({
  img: {
    data: Buffer,
    contentType: String,
  },
  like: {
    type: Number,
    required: false,
    defaultValue: 0,
  },
  // add a 1 to many collection relation here.
});

module.exports = mongoose.model("Image", imageSchema, "Images");
