const express = require("express");
const { createImage } = require("./imageServices");
const router = express.Router();

//storage middleware
const multer = require("multer");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "image-uploads");
  },
  filename: (req, file, cb) => {
    cb(null, file.fieldname + "-" + Date.now());
  },
});

const upload = multer({ storage: storage });

router
  // GET /user
  .route("/")
  .post(upload.single("image"), createImage);

exports.router = router;
