const Image = require("./../../models/image");
const fs = require("fs");
const ObjectId = require("mongodb").ObjectId;
const path = require("path");

const createImage = async (req, res) => {
  const files = Object.values(req.files);
  const { name } = files[0];
  const filePath = __dirname + "/image-uploads/" + name;

  const newImage = new Image({
    img: {
      data: fs.readFileSync(path.join(filePath)),
      contentType: "image/png",
    },
  });
  newImage.save();
  return res.stats(201).send({ data: `${name} has been uploaded` });
};

module.exports = {
  createImage,
};
