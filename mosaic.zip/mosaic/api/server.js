const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const formData = require("express-form-data");

const { router: ImageRoute } = require("./routes/image/imageRoutes");

// constants
const { PORT, PATH } = require("./constants");
// instance of app
const app = express();

//app start configuration
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(formData.parse());
app.use("/upload", ImageRoute);

mongoose
  .connect(PATH, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(async () => {
    console.log("Connected to database at 27017");
    app.listen(PORT, () => {
      console.log(`Server is running on PORT: ${PORT}`);
    });
  });
