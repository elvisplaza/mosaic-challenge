import React from "react";
import "./App.css";

//components
import UploadForm from "./components/UploadForm/UploadForm";

function App() {
  return (
    <div className='App'>
      <header className='App-header'>
        <UploadForm />
      </header>
    </div>
  );
}

export default App;
