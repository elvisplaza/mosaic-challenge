import React, { Component } from "react";

//constants
import { urlUploadPath } from "./../../helpers/constants";

class UploadForm extends Component {
  constructor(props) {
    super();
    this.state = {
      message: "",
      imageFiles: [],
    };
  }

  onSubmitFile = (e) => {
    e.preventDefault();
    const { imageFiles } = this.state;
    let formData = new FormData();
    // error handling
    if (imageFiles.length <= 0) {
      return this.setState({
        message: "Please upload a file",
      });
    }

    imageFiles.forEach((file, index) => {
      formData.append(index, file);
    });

    return fetch(urlUploadPath, {
      method: "POST",
      body: formData,
    }).then((data) => {
      console.log(data);
    });
  };

  onHandleChange = (e) => {
    const files = Array.from(e.target.files);
    return this.setState({
      message: "",
      imageFiles: files,
    });
  };
  render() {
    const { imageFiles, message } = this.state;
    return (
      <section>
        <form onSubmit={this.onSubmitFile}>
          <h2>Select File Image</h2>
          <label>
            <input type='file' id='imageFiles' onChange={this.onHandleChange} />
          </label>
          <button type='submit'>
            <p>Submit</p>
          </button>
          <p>{message}</p>
        </form>
      </section>
    );
  }
}

export default UploadForm;
