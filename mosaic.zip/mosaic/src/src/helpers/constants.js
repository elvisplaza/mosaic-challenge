export const urlUploadPath = "http://localhost:3002/upload";
